## Outdated versions

Old patch versions can be useful on distros that do not keep up with upstream developments.  This section is broken down by linux version and by gcc version.  Note that the most contemporary version of the patch is stored one level up.

## WARNING

I am not actively backporting fixes/features to these.  Use them as-is.  I highly recommend that you use the current version.
